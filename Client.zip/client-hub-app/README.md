# Client Hub prototype

Mobile-first single-page client management PWA prototype.

## Run locally

Because service workers require a secure context, use a local HTTP server rather than opening `index.html` directly.

Example with Python:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080` in your browser.

## Included

- Dashboard with client/follow-up/task/meeting stats
- Client list, search and profiles
- Unified client view with notes, demo emails, meetings and tasks
- Add/edit clients
- Tasks with completion state
- Calendar view
- Settings for future Gmail/Microsoft 365 and Google/Outlook OAuth connections
- Local browser storage
- JSON export
- PWA manifest and service worker

## Production integration

The UI is intentionally frontend-only. For real email/calendar data, add a backend that performs OAuth 2.0 authorization, securely stores refresh tokens, calls Gmail/Microsoft Graph/Google Calendar APIs, and returns only the data needed by the client UI.
