const KEY='clientHubDataV1';
const seed={
 clients:[
  {id:'c1',name:'Sarah Thompson',company:'Northstar Consulting',email:'sarah@northstar.example',phone:'+64 21 555 014',status:'Active',tags:['VIP','Retainer'],notes:'Quarterly strategy client. Prefers morning meetings.',lastContact:'2026-08-09',nextFollowUp:'2026-08-14'},
  {id:'c2',name:'James Patel',company:'Harbour Foods',email:'james@harbour.example',phone:'+64 27 555 018',status:'Prospect',tags:['Proposal'],notes:'Proposal sent. Decision expected this week.',lastContact:'2026-08-07',nextFollowUp:'2026-08-12'},
  {id:'c3',name:'Mia Chen',company:'Studio Eight',email:'mia@studioeight.example',phone:'+64 22 555 011',status:'Active',tags:['Creative'],notes:'New campaign planning and monthly reporting.',lastContact:'2026-08-05',nextFollowUp:'2026-08-19'},
  {id:'c4',name:'Daniel Brooks',company:'Greenline Property',email:'daniel@greenline.example',phone:'+64 20 555 016',status:'On hold',tags:['Paused'],notes:'Project paused until September.',lastContact:'2026-07-29',nextFollowUp:'2026-09-02'}
 ],
 emails:[
  {id:'e1',clientId:'c1',direction:'in',subject:'August priorities',preview:'Can we focus next week on the rollout plan and timing?',date:'2026-08-09T10:15:00'},
  {id:'e2',clientId:'c2',direction:'out',subject:'Proposal and next steps',preview:'Thanks James — attaching the revised proposal and timeline.',date:'2026-08-07T15:10:00'},
  {id:'e3',clientId:'c3',direction:'in',subject:'Campaign assets',preview:'The new photography set is ready for review.',date:'2026-08-05T11:40:00'}
 ],
 events:[
  {id:'v1',clientId:'c1',title:'Northstar quarterly review',date:'2026-08-12',time:'09:30',location:'Google Meet'},
  {id:'v2',clientId:'c2',title:'Proposal follow-up',date:'2026-08-13',time:'14:00',location:'Phone'},
  {id:'v3',clientId:'c3',title:'Campaign planning',date:'2026-08-15',time:'11:00',location:'Studio Eight'}
 ],
 tasks:[
  {id:'t1',clientId:'c2',title:'Follow up on proposal',due:'2026-08-12',done:false},
  {id:'t2',clientId:'c1',title:'Send revised rollout timeline',due:'2026-08-13',done:false},
  {id:'t3',clientId:'c3',title:'Review campaign assets',due:'2026-08-11',done:true}
 ]
};
let state=load(); let view='dashboard'; let selectedClient=null;
function load(){try{return JSON.parse(localStorage.getItem(KEY))||structuredClone(seed)}catch{return structuredClone(seed)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function esc(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function initials(name){return name.split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase()}
function fmtDate(s){return new Intl.DateTimeFormat('en-NZ',{day:'numeric',month:'short'}).format(new Date(s+'T00:00:00'))}
function fmtDateTime(s){return new Intl.DateTimeFormat('en-NZ',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'}).format(new Date(s))}
function client(id){return state.clients.find(c=>c.id===id)}
function statusClass(s){return s==='Active'?'good':s==='Prospect'?'warn':s==='On hold'?'danger':''}
function render(){
 document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 const titles={dashboard:'Dashboard',clients:'Clients',calendar:'Calendar',tasks:'Tasks',settings:'Settings'};
 document.getElementById('pageTitle').textContent=selectedClient?'Client profile':titles[view];
 document.getElementById('app').innerHTML=selectedClient?renderProfile():({dashboard:renderDashboard,clients:renderClients,calendar:renderCalendar,tasks:renderTasks,settings:renderSettings}[view])();
}
function renderDashboard(){
 const follow=state.clients.filter(c=>c.nextFollowUp<='2026-08-15').length; const open=state.tasks.filter(t=>!t.done).length;
 const upcoming=state.events.filter(e=>e.date>='2026-08-11').slice(0,3);
 return `<div class="grid stats"><div class="stat"><div class="label">Clients</div><div class="value">${state.clients.length}</div></div><div class="stat"><div class="label">Follow-ups</div><div class="value">${follow}</div></div><div class="stat"><div class="label">Open tasks</div><div class="value">${open}</div></div><div class="stat"><div class="label">Upcoming meetings</div><div class="value">${state.events.length}</div></div></div>
 <section class="section"><div class="hero"><h2>Everything about your clients.</h2><p>One place for client details, activity, email context, meetings and follow-ups.</p><div class="actions"><button class="btn primary" id="heroAdd">Add client</button><button class="btn secondary" id="heroClients">View clients</button></div></div></section>
 <section class="section"><div class="section-head"><h2>Today's focus</h2><button class="link-btn" id="seeTasks">See tasks</button></div><div class="card">${state.tasks.filter(t=>!t.done).slice(0,3).map(taskHtml).join('')||'<div class="empty">No open tasks.</div>'}</div></section>
 <section class="section"><div class="section-head"><h2>Upcoming meetings</h2><button class="link-btn" id="seeCalendar">Calendar</button></div><div class="card">${upcoming.map(eventHtml).join('')||'<div class="empty">No upcoming meetings.</div>'}</div></section>
 <section class="section"><div class="section-head"><h2>Recent activity</h2></div><div class="card">${state.emails.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3).map(email=>`<div class="item-row"><div class="avatar">✉</div><div class="grow"><div class="title">${esc(email.subject)}</div><div class="muted">${esc(client(email.clientId)?.name||'Unknown')} · ${fmtDateTime(email.date)}</div><div class="muted">${esc(email.preview)}</div></div></div>`).join('')}</div></section>`;
}
function taskHtml(t){return `<div class="item-row"><div class="grow"><div class="title">${esc(t.title)}</div><div class="muted">${esc(client(t.clientId)?.name||'')} · due ${fmtDate(t.due)}</div></div><button class="btn link" data-task="${t.id}">${t.done?'Done':'Complete'}</button></div>`}
function eventHtml(e){return `<div class="event"><div class="event-time">${esc(e.time)}</div><div class="grow"><div class="title">${esc(e.title)}</div><div class="muted">${esc(client(e.clientId)?.name||'')} · ${esc(e.location)} · ${fmtDate(e.date)}</div></div></div>`}
function renderClients(){return `<div class="searchbar"><input id="clientSearch" placeholder="Search clients, companies, email..."><button class="btn primary" id="addClientInline">Add</button></div><div id="clientList" class="card">${state.clients.map(clientCard).join('')}</div>`}
function clientCard(c){return `<div class="client-row" data-search="${esc((c.name+' '+c.company+' '+c.email+' '+c.tags.join(' ')).toLowerCase())}"><div class="avatar">${initials(c.name)}</div><div class="grow"><div class="title">${esc(c.name)}</div><div class="muted">${esc(c.company)} · ${esc(c.email)}</div><div class="actions"><span class="pill ${statusClass(c.status)}">${esc(c.status)}</span>${c.tags.slice(0,2).map(t=>`<span class="pill">${esc(t)}</span>`).join('')}</div></div><button class="btn secondary" data-client="${c.id}">Open</button></div>`}
function renderCalendar(){const groups=[...new Set(state.events.map(e=>e.date))].sort();return `<div class="notice">Calendar is currently using demo data. The connection area in Settings is ready for Google Calendar / Outlook OAuth wiring.</div>${groups.map(d=>`<div class="section calendar-day"><h3>${fmtDate(d)}</h3><div class="card">${state.events.filter(e=>e.date===d).map(eventHtml).join('')}</div></div>`).join('')}`}
function renderTasks(){return `<div class="section-head"><h2>Tasks</h2><button class="btn primary" id="addTask">New task</button></div><div class="card">${state.tasks.map(taskHtml).join('')||'<div class="empty">No tasks yet.</div>'}</div>`}
function renderSettings(){return `<div class="card"><div class="settings-row"><div><div class="title">Email connection</div><div class="muted">Gmail / Microsoft 365 via OAuth 2.0</div></div><button class="btn secondary" id="connectEmail">Connect</button></div><div class="settings-row"><div><div class="title">Calendar connection</div><div class="muted">Google Calendar / Outlook Calendar</div></div><button class="btn secondary" id="connectCalendar">Connect</button></div><div class="settings-row"><div><div class="title">Local data</div><div class="muted">Prototype data is stored in this browser.</div></div><button class="btn secondary" id="exportData">Export</button></div><div class="settings-row"><div><div class="title">Reset demo</div><div class="muted">Restore the sample client workspace.</div></div><button class="btn danger" id="resetData">Reset</button></div></div><section class="section"><div class="notice"><strong>Production note:</strong> real email and calendar integration should use a backend for OAuth token exchange, encryption, permissions and secure API calls. This frontend is intentionally self-contained for prototyping.</div></section>`}
function renderProfile(){const c=client(selectedClient);const emails=state.emails.filter(e=>e.clientId===c.id).sort((a,b)=>b.date.localeCompare(a.date));const events=state.events.filter(e=>e.clientId===c.id).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));const tasks=state.tasks.filter(t=>t.clientId===c.id);
 return `<button class="link-btn" id="backClients">← Back to clients</button><section class="section"><div class="hero"><div class="avatar" style="background:rgba(255,255,255,.15);color:#fff">${initials(c.name)}</div><h2 style="margin-top:12px">${esc(c.name)}</h2><p>${esc(c.company)} · ${esc(c.email)}</p><div class="actions"><span class="pill ${statusClass(c.status)}">${esc(c.status)}</span>${c.tags.map(t=>`<span class="pill">${esc(t)}</span>`).join('')}</div><div class="actions"><button class="btn secondary" data-mail="${c.id}">Email</button><button class="btn secondary" data-call="${c.id}">Call</button><button class="btn secondary" id="scheduleMeeting">Schedule</button><button class="btn secondary" id="editClient">Edit</button></div></div></section>
 <section class="section"><div class="section-head"><h2>Contact</h2></div><div class="card"><div class="item-row"><div class="grow"><div class="muted">Phone</div><div class="title">${esc(c.phone||'Not provided')}</div></div></div><div class="item-row"><div class="grow"><div class="muted">Last contact</div><div class="title">${fmtDate(c.lastContact)}</div></div></div><div class="item-row"><div class="grow"><div class="muted">Next follow-up</div><div class="title">${fmtDate(c.nextFollowUp)}</div></div></div></div></section>
 <section class="section"><div class="section-head"><h2>Notes</h2><button class="link-btn" id="editClient2">Edit</button></div><div class="card"><div class="muted" style="font-size:14px">${esc(c.notes||'No notes yet.')}</div></div></section>
 <section class="section"><div class="section-head"><h2>Upcoming meetings</h2></div><div class="card">${events.filter(e=>e.date>='2026-08-11').map(eventHtml).join('')||'<div class="empty">No upcoming meetings.</div>'}</div></section>
 <section class="section"><div class="section-head"><h2>Email history</h2></div><div class="card">${emails.map(e=>`<div class="item-row"><div class="avatar">✉</div><div class="grow"><div class="title">${esc(e.subject)}</div><div class="muted">${fmtDateTime(e.date)} · ${e.direction==='in'?'Received':'Sent'}</div><div class="muted">${esc(e.preview)}</div></div></div>`).join('')||'<div class="empty">No demo emails yet.</div>'}</div></section>
 <section class="section"><div class="section-head"><h2>Tasks</h2></div><div class="card">${tasks.map(taskHtml).join('')||'<div class="empty">No tasks for this client.</div>'}</div></section>`}
function openModal(editId=null){const modal=document.getElementById('modal');modal.classList.remove('hidden');const form=document.getElementById('clientForm');form.reset();form.dataset.edit=editId||'';document.getElementById('modalTitle').textContent=editId?'Edit client':'Add client';if(editId){const c=client(editId);Object.entries(c).forEach(([k,v])=>{const f=form.elements[k];if(f)f.value=Array.isArray(v)?v.join(', '):v})}}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function bind(){document.querySelectorAll('.nav-btn').forEach(b=>b.onclick=()=>{selectedClient=null;view=b.dataset.view;render()});document.getElementById('quickAddBtn').onclick=()=>openModal();document.querySelectorAll('[data-close-modal]').forEach(x=>x.onclick=closeModal);
 document.getElementById('clientForm').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const data={name:f.get('name').trim(),company:f.get('company').trim(),email:f.get('email').trim(),phone:f.get('phone').trim(),status:f.get('status'),tags:f.get('tags').split(',').map(x=>x.trim()).filter(Boolean),notes:f.get('notes').trim()};const id=e.target.dataset.edit;if(id){Object.assign(client(id),data)}else{const today='2026-08-11';state.clients.push({id:'c'+Date.now(),...data,lastContact:today,nextFollowUp:today})}save();closeModal();render();bind()};
 document.querySelectorAll('[data-client]').forEach(b=>b.onclick=()=>{selectedClient=b.dataset.client;render();bind()});
 document.querySelectorAll('[data-task]').forEach(b=>b.onclick=()=>{const t=state.tasks.find(x=>x.id===b.dataset.task);t.done=!t.done;save();render();bind()});
 const s=document.getElementById('clientSearch'); if(s)s.oninput=()=>{const q=s.value.toLowerCase();document.querySelectorAll('#clientList .client-row').forEach(r=>r.style.display=r.dataset.search.includes(q)?'flex':'none')};
 ['heroAdd','addClientInline'].forEach(id=>{const el=document.getElementById(id);if(el)el.onclick=()=>openModal()});
 const vc=document.getElementById('heroClients');if(vc)vc.onclick=()=>{view='clients';render();bind()};
 const st=document.getElementById('seeTasks');if(st)st.onclick=()=>{view='tasks';render();bind()};
 const sc=document.getElementById('seeCalendar');if(sc)sc.onclick=()=>{view='calendar';render();bind()};
 document.getElementById('backClients')?.addEventListener('click',()=>{selectedClient=null;view='clients';render();bind()});
 ['editClient','editClient2'].forEach(id=>document.getElementById(id)?.addEventListener('click',()=>openModal(selectedClient)));
 document.querySelectorAll('[data-mail]').forEach(b=>b.onclick=()=>{const c=client(b.dataset.mail);location.href=`mailto:${encodeURIComponent(c.email)}`});
 document.querySelectorAll('[data-call]').forEach(b=>b.onclick=()=>{const c=client(b.dataset.call);location.href=`tel:${encodeURIComponent(c.phone)}`});
 document.getElementById('connectEmail')?.addEventListener('click',()=>alert('Prototype ready: connect this button to your backend OAuth flow for Gmail or Microsoft 365.'));
 document.getElementById('connectCalendar')?.addEventListener('click',()=>alert('Prototype ready: connect this button to your backend OAuth flow for Google Calendar or Outlook Calendar.'));
 document.getElementById('exportData')?.addEventListener('click',()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='client-hub-export.json';a.click();URL.revokeObjectURL(a.href)});
 document.getElementById('resetData')?.addEventListener('click',()=>{if(confirm('Reset all browser data to the demo dataset?')){state=structuredClone(seed);save();render();bind()}});
 document.getElementById('addTask')?.addEventListener('click',()=>{const title=prompt('Task name');if(!title)return;const pick=prompt('Client name (exact match)')||'';const c=state.clients.find(x=>x.name.toLowerCase()===pick.toLowerCase())||state.clients[0];state.tasks.push({id:'t'+Date.now(),clientId:c.id,title,due:'2026-08-11',done:false});save();render();bind()});
 document.getElementById('scheduleMeeting')?.addEventListener('click',()=>alert('Prototype ready: launch your Google/Outlook event creation flow here.'));
}
render();bind();
